<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Hello</title>
  <?php wp_head(); ?>
  <link rel="stylesheet" href=" <?php echo get_stylesheet_uri(); ?>">
</head>
<body>
</header>
  
